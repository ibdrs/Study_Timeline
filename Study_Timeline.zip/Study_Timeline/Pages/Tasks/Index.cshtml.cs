using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Study_Timeline.View.Pages.Tasks
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
